package com.seuprojeto.loginapi;

import org.springframework.stereotype.Service; // <- Import necessário
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@Service 
public class UsuarioService {
    private List<Usuario> usuarios = new ArrayList<>();

    public UsuarioService() {
        carregarUsuariosDoCSV();
    }

    private void carregarUsuariosDoCSV() {
        try {
            InputStream is = getClass().getResourceAsStream("/usuarios.csv");
            if (is == null) {
                System.out.println("Arquivo usuarios.csv não encontrado!");
                return;
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String linha;
            br.readLine(); // Pula o cabeçalho
            while ((linha = br.readLine()) != null) {
                String[] partes = linha.split(",");
                if (partes.length >= 2) {
                    String email = partes[0];
                    String senha = partes[1];
                    usuarios.add(new Usuario(email, senha));
                }
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean validarLogin(String email, String senha) {
    	return email.equals("admin@email.com") && senha.equals("1234");
    }
    
}
